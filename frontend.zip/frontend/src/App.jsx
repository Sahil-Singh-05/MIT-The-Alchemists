import { startTransition, useDeferredValue, useEffect, useRef, useState } from "react";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "";
const MESSAGE_META_STORAGE_KEY = "the-alchemists-message-meta-v1";

const ASSETS = {
  brand: "/assets/image-Photoroom.png",
  search: "/assets/image-Photoroom(1).png",
  profile: "/assets/image-Photoroom(6).png",
  message: "/assets/image-Photoroom(8).png",
  ticket: "/assets/image-Photoroom(9).png",
};

const NAV_ITEMS = [
  { id: "chat", label: "New Chat", icon: ASSETS.message },
  { id: "search", label: "Search Chat", icon: ASSETS.search },
  { id: "tickets", label: "Tickets", icon: ASSETS.ticket, accent: true },
];

const SHOWCASE_RECENTS = [
  { id: "mock-hackathon", title: "Hackathon Problem", placeholder: true },
  { id: "mock-anaconda", title: "Anaconda Setup", placeholder: true },
];

function buildUrl(path) {
  return `${API_BASE_URL}${path}`;
}

async function apiRequest(path, options = {}) {
  const isFormData = options.body instanceof FormData;
  const response = await fetch(buildUrl(path), {
    ...options,
    headers: {
      ...(isFormData ? {} : { "Content-Type": "application/json" }),
      ...(options.headers ?? {}),
    },
  });

  if (!response.ok) {
    let detail = "Request failed.";

    try {
      const payload = await response.json();
      detail = payload.detail ?? detail;
    } catch {
      detail = response.statusText || detail;
    }

    throw new Error(detail);
  }

  if (response.status === 204) {
    return null;
  }

  return response.json();
}

function readStoredMessageMeta() {
  if (typeof window === "undefined") {
    return {};
  }

  try {
    const raw = window.localStorage.getItem(MESSAGE_META_STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveStoredMessageMeta(value) {
  if (typeof window === "undefined") {
    return;
  }

  window.localStorage.setItem(MESSAGE_META_STORAGE_KEY, JSON.stringify(value));
}

function hydrateMessages(sessionId, history, latestAssistantMeta = null) {
  const storedMeta = readStoredMessageMeta();
  const normalized = history.map((message) => ({
    role: message.role,
    content: message.content,
    timestamp: message.timestamp,
  }));

  if (latestAssistantMeta) {
    const lastAssistantIndex = [...normalized]
      .map((message) => message.role)
      .lastIndexOf("assistant");

    if (lastAssistantIndex >= 0) {
      storedMeta[`${sessionId}:${normalized[lastAssistantIndex].timestamp}`] = latestAssistantMeta;
      saveStoredMessageMeta(storedMeta);
    }
  }

  return normalized.map((message) => ({
    ...message,
    ...(storedMeta[`${sessionId}:${message.timestamp}`] ?? {}),
  }));
}

function formatTimestamp(timestamp) {
  if (!timestamp) {
    return "";
  }

  const date = new Date(timestamp);

  if (Number.isNaN(date.getTime())) {
    return "";
  }

  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

function formatTicketDate(timestamp) {
  if (!timestamp) {
    return "Pending";
  }

  const date = new Date(timestamp);

  if (Number.isNaN(date.getTime())) {
    return "Pending";
  }

  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
  }).format(date);
}

function truncateLabel(value, maxLength = 20) {
  if (!value) {
    return "";
  }

  return value.length > maxLength ? `${value.slice(0, maxLength)}...` : value;
}

function humanizeError(error) {
  return error instanceof Error ? error.message : "The backend is not responding yet.";
}

function findPreviousQuestion(messages, index) {
  for (let cursor = index - 1; cursor >= 0; cursor -= 1) {
    if (messages[cursor]?.role === "user") {
      return messages[cursor].content;
    }
  }

  return "";
}

function TypingBubble() {
  return (
    <div className="typing-bubble" aria-label="Assistant is thinking">
      <span />
      <span />
      <span />
    </div>
  );
}

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeView, setActiveView] = useState("chat");
  const [sessions, setSessions] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [currentSessionId, setCurrentSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState("");
  const [query, setQuery] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingSession, setIsLoadingSession] = useState(false);
  const [isBooting, setIsBooting] = useState(true);
  const [error, setError] = useState("");
  const [creatingTicketId, setCreatingTicketId] = useState("");
  const endRef = useRef(null);

  const deferredQuery = useDeferredValue(query);
  const visibleSessions = sessions.filter((session) =>
    session.title.toLowerCase().includes(deferredQuery.trim().toLowerCase()),
  );
  const recentSessions = sessions.length
    ? sessions.slice(0, 2).map((session) => ({ ...session, placeholder: false }))
    : SHOWCASE_RECENTS;
  const isLanding = activeView === "chat" && messages.length === 0 && !isLoadingSession;
  const currentSession = sessions.find((session) => session.id === currentSessionId) ?? null;

  useEffect(() => {
    let ignore = false;

    async function bootstrap() {
      try {
        const [sessionData, ticketData] = await Promise.all([
          apiRequest("/chat/sessions").catch(() => []),
          apiRequest("/crm/tickets").catch(() => []),
        ]);

        if (ignore) {
          return;
        }

        startTransition(() => {
          setSessions(sessionData);
          setTickets(ticketData);
        });
      } finally {
        if (!ignore) {
          setIsBooting(false);
        }
      }
    }

    bootstrap();

    return () => {
      ignore = true;
    };
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, activeView, isSubmitting]);

  async function refreshSessions() {
    try {
      const sessionData = await apiRequest("/chat/sessions");
      startTransition(() => {
        setSessions(sessionData);
      });
    } catch (refreshError) {
      setError(humanizeError(refreshError));
    }
  }

  async function refreshTickets() {
    try {
      const ticketData = await apiRequest("/crm/tickets");
      startTransition(() => {
        setTickets(ticketData);
      });
    } catch (refreshError) {
      setError(humanizeError(refreshError));
    }
  }

  async function openSession(sessionId) {
    if (!sidebarOpen) {
      setSidebarOpen(true);
      return;
    }

    setError("");
    setActiveView("chat");
    setCurrentSessionId(sessionId);
    setIsLoadingSession(true);

    try {
      const history = await apiRequest(`/chat/session/${sessionId}`);
      setMessages(hydrateMessages(sessionId, history));
    } catch (sessionError) {
      setMessages([]);
      setError(humanizeError(sessionError));
    } finally {
      setIsLoadingSession(false);
    }
  }

  function handleNewChat() {
    if (!sidebarOpen) {
      setSidebarOpen(true);
      return;
    }

    setActiveView("chat");
    setCurrentSessionId(null);
    setMessages([]);
    setDraft("");
    setError("");
  }

  async function handleSubmit(event) {
    event.preventDefault();

    const question = draft.trim();

    if (!question || isSubmitting) {
      return;
    }

    const pendingTimestamp = new Date().toISOString();
    let sessionId = currentSessionId;

    setActiveView("chat");
    setError("");
    setDraft("");
    setIsSubmitting(true);
    setMessages((previous) => [
      ...previous,
      {
        role: "user",
        content: question,
        timestamp: pendingTimestamp,
        isPending: true,
      },
    ]);

    try {
      if (!sessionId) {
        const session = await apiRequest("/chat/session", {
          method: "POST",
          body: JSON.stringify({ title: "New Chat" }),
        });
        sessionId = session.id;
        setCurrentSessionId(sessionId);
      }

      const answer = await apiRequest("/chat/ask", {
        method: "POST",
        body: JSON.stringify({
          session_id: sessionId,
          question,
        }),
      });

      const history = await apiRequest(`/chat/session/${sessionId}`);
      setMessages(
        hydrateMessages(sessionId, history, {
          question,
          sources: answer.sources,
          hasConflict: answer.has_conflict,
          conflictNote: answer.conflict_note,
          hasAnswer: answer.has_answer,
          noAnswerReason: answer.no_answer_reason,
        }),
      );
      await refreshSessions();
    } catch (submitError) {
      setMessages((previous) => [
        ...previous.map((message) =>
          message.timestamp === pendingTimestamp ? { ...message, isPending: false } : message,
        ),
        {
          role: "assistant",
          content: humanizeError(submitError),
          timestamp: new Date().toISOString(),
          isError: true,
        },
      ]);
      setError(humanizeError(submitError));
    } finally {
      setIsSubmitting(false);
    }
  }

  async function createTicket(message, index) {
    if (!currentSessionId || !message.sources?.length) {
      return;
    }

    const question = message.question || findPreviousQuestion(messages, index);

    if (!question) {
      return;
    }

    setCreatingTicketId(message.timestamp);
    setError("");

    try {
      await apiRequest("/crm/ticket", {
        method: "POST",
        body: JSON.stringify({
          session_id: currentSessionId,
          client_name: "Internal SME",
          priority: message.hasConflict ? "High" : "Medium",
          question,
          answer: message.content,
          sources: message.sources,
        }),
      });

      await refreshTickets();
      setActiveView("tickets");
    } catch (ticketError) {
      setError(humanizeError(ticketError));
    } finally {
      setCreatingTicketId("");
    }
  }

  function renderComposer(isCompact = false) {
    return (
      <form
        className={`composer ${isCompact ? "composer--compact" : ""}`}
        onSubmit={handleSubmit}
      >
        <img alt="" className="composer__icon composer__icon--left" src={ASSETS.search} />
        <textarea
          className="composer__input"
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          placeholder={isLanding ? "" : "Ask the knowledge base anything..."}
          rows={1}
        />
        <button
          className="composer__submit"
          type="submit"
          disabled={!draft.trim() || isSubmitting}
          aria-label="Send message"
        >
          <img alt="" src={ASSETS.message} />
        </button>
      </form>
    );
  }

  function renderChatView() {
    if (isLanding) {
      return (
        <section className="landing">
          <div className="landing__brand">
            <img alt="The Alchemists flask" className="landing__logo" src={ASSETS.brand} />
            <h1>ALCHEMIST</h1>
          </div>
          <div className="landing__composer">{renderComposer()}</div>
        </section>
      );
    }

    return (
      <section className="chat-view">
        <header className="chat-view__header">
          <div className="chat-view__title">
            <img alt="" src={ASSETS.brand} />
            <div>
              <p>{currentSession ? truncateLabel(currentSession.title, 34) : "New Chat"}</p>
              <span>Pixel RAG workspace</span>
            </div>
          </div>
        </header>

        <div className="chat-view__scroll">
          {isLoadingSession ? (
            <div className="empty-card empty-card--loading">
              <TypingBubble />
              <p>Loading session...</p>
            </div>
          ) : null}

          {!isLoadingSession
            ? messages.map((message, index) => {
                const canCreateTicket = Boolean(message.sources?.length);

                return (
                  <article
                    key={`${message.timestamp}-${index}`}
                    className={`message-card message-card--${message.role} ${
                      message.isError ? "message-card--error" : ""
                    }`}
                  >
                    <div className="message-card__meta">
                      <span>{message.role === "user" ? "You" : "Alchemist"}</span>
                      <time>{formatTimestamp(message.timestamp)}</time>
                    </div>
                    <p>{message.content}</p>

                    {message.role === "assistant" && message.hasConflict ? (
                      <div className="message-card__note">{message.conflictNote}</div>
                    ) : null}

                    {message.role === "assistant" && message.sources?.length ? (
                      <div className="sources">
                        {message.sources.map((source) => (
                          <span
                            className="source-chip"
                            key={`${source.file}-${source.location}-${source.date}`}
                          >
                            {source.file}
                          </span>
                        ))}
                      </div>
                    ) : null}

                    {canCreateTicket ? (
                      <button
                        className="ticket-button"
                        type="button"
                        onClick={() => createTicket(message, index)}
                        disabled={creatingTicketId === message.timestamp}
                      >
                        {creatingTicketId === message.timestamp ? "Creating..." : "Create Ticket"}
                      </button>
                    ) : null}
                  </article>
                );
              })
            : null}

          {isSubmitting ? (
            <article className="message-card message-card--assistant message-card--typing">
              <div className="message-card__meta">
                <span>Alchemist</span>
                <time>Now</time>
              </div>
              <TypingBubble />
            </article>
          ) : null}
          <div ref={endRef} />
        </div>

        <div className="chat-view__composer">{renderComposer(true)}</div>
      </section>
    );
  }

  function renderSearchView() {
    return (
      <section className="panel-view">
        <header className="panel-view__header">
          <p>Search Chat</p>
          <span>Find prior RAG conversations and jump back in.</span>
        </header>

        <label className="search-shell">
          <img alt="" src={ASSETS.search} />
          <input
            type="text"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search by session title..."
          />
        </label>

        <div className="panel-grid">
          {visibleSessions.length ? (
            visibleSessions.map((session) => (
              <button
                className="panel-card"
                key={session.id}
                type="button"
                onClick={() => openSession(session.id)}
              >
                <strong>{session.title}</strong>
                <span>{session.message_count} messages</span>
                <small>{formatTicketDate(session.created_at)}</small>
              </button>
            ))
          ) : (
            <div className="empty-card">
              <p>No matching chats yet.</p>
            </div>
          )}
        </div>
      </section>
    );
  }

  function renderTicketsView() {
    return (
      <section className="panel-view">
        <header className="panel-view__header">
          <p>Tickets</p>
          <span>Auto-filled support tickets created from grounded answers.</span>
        </header>

        <div className="panel-grid">
          {tickets.length ? (
            tickets.map((ticket) => (
              <article className="ticket-card" key={ticket.ticket_id}>
                <div className="ticket-card__header">
                  <strong>{ticket.subject}</strong>
                  <span>{ticket.status}</span>
                </div>
                <p>{ticket.client_name}</p>
                <small>
                  {ticket.ticket_id} | {ticket.priority} | {formatTicketDate(ticket.created_at)}
                </small>
                <div className="sources">
                  {ticket.sources_cited.map((source) => (
                    <span className="source-chip source-chip--ticket" key={source}>
                      {source}
                    </span>
                  ))}
                </div>
              </article>
            ))
          ) : (
            <div className="empty-card">
              <p>No tickets yet. Create one from an assistant answer.</p>
            </div>
          )}
        </div>
      </section>
    );
  }

  return (
    <div className={`app-shell ${sidebarOpen ? "app-shell--open" : "app-shell--collapsed"}`}>
      <aside className={`sidebar ${sidebarOpen ? "sidebar--open" : "sidebar--collapsed"}`}>
        <div className="sidebar__top">
          <button className="sidebar__brand" type="button" onClick={handleNewChat}>
            <img alt="The Alchemists" src={ASSETS.brand} />
          </button>
        </div>

        <nav className="sidebar__nav">
          {NAV_ITEMS.map((item) => (
            <button
              className={`sidebar__nav-item ${activeView === item.id ? "is-active" : ""}`}
              key={item.id}
              type="button"
              onClick={() => {
                if (!sidebarOpen) {
                  setSidebarOpen(true);
                  return;
                }

                if (item.id === "chat") {
                  handleNewChat();
                  return;
                }

                setActiveView(item.id);
                setError("");
              }}
            >
              <img
                alt=""
                className={
                  item.accent ? "sidebar__nav-icon sidebar__nav-icon--accent" : "sidebar__nav-icon"
                }
                src={item.icon}
              />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar__section">
          <div className="sidebar__section-header">
            <span>Recents</span>
            <small>v</small>
          </div>

          <div className="sidebar__recents">
            {recentSessions.map((session) => (
              <button
                className="sidebar__recent"
                disabled={session.placeholder}
                key={session.id}
                type="button"
                onClick={() => openSession(session.id)}
              >
                {truncateLabel(session.title, 22)}
              </button>
            ))}
          </div>
        </div>

        <div className="sidebar__profile">
          <img alt="" src={ASSETS.profile} />
          <span>Sahil Singh</span>
        </div>
      </aside>

      {sidebarOpen ? (
        <button
          aria-label="Collapse sidebar"
          className="sidebar-scrim"
          type="button"
          onClick={() => setSidebarOpen(false)}
        />
      ) : null}

      <main className="workspace">
        {error ? <div className="workspace__notice">{error}</div> : null}
        {isBooting ? <div className="workspace__status">Loading workspace...</div> : null}

        {activeView === "chat" ? renderChatView() : null}
        {activeView === "search" ? renderSearchView() : null}
        {activeView === "tickets" ? renderTicketsView() : null}
      </main>
    </div>
  );
}

export default App;
